// include necessary header
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>

// define the marco 
#define MYIOCTL_MAGIC 'k'
#define MYIOCTL_RESET _IO(MYIOCTL_MAGIC, 0)
#define MYIOCTL_GET_COUNT _IOR(MYIOCTL_MAGIC, 1, int)
#define MYIOCTL_INCREMENT _IOW(MYIOCTL_MAGIC, 2, int)

//define the file path for storing the counter value
#define COUNTER_FILE_PATH "myioctl_persistent_counter.txt"

// fill the module information
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Group 32");
MODULE_DESCRIPTION("Simple IOCTL Example");

// declare the global variables
static int myioctl_major;
static int count = 0;

// function prototypes
static int myioctl_open(struct inode *inode, struct file *filp);
static int myioctl_release(struct inode *inode, struct file *filp);
static long myioctl_ioctl(struct file *flip, unsigned int cmd, unsigned long arg);

// file operations structure
static const struct file_operations myioctl_fops = {
    .open = myioctl_open,
    .release = myioctl_release,
    .unlocked_ioctl = myioctl_ioctl,
};

//save counter value function
static int saveCounterValueToFile(int counter_value) {
    struct file *file;
    ssize_t ret = 0;

    file = filp_open(COUNTER_FILE_PATH, O_WRONLY | O_CREAT, 0644);
    if (IS_ERR(file)) {
        pr_err("Error opening counter file\n");
        ret = PTR_ERR(file);
    } else {
    	//as we will store/rewrite the value of counter then use the kernel_write
        ret = kernel_write(file, (const char *)&counter_value, sizeof(int), &file->f_pos);
        filp_close(file, NULL);
    }

    return ret;
}

//read counter value
static int readCounterValueFromFile(int *counter_value) {
    struct file *file;
    ssize_t ret = 0;

    file = filp_open(COUNTER_FILE_PATH, O_RDONLY, 0);
    if (IS_ERR(file)) {
        pr_err("Error opening counter file\n");
        ret = PTR_ERR(file);
    } else {
    	//as we want to load the counter value so we use the kernel_read
        ret = kernel_read(file, (char *)counter_value, sizeof(int), &file->f_pos);
        filp_close(file, NULL);
    }

    return ret;
}

// module initialization
static int __init myioctl_init(void) {
    myioctl_major = register_chrdev(0, "myioctl", &myioctl_fops);

    if (myioctl_major < 0) {
        pr_err("Failed to register character device\n");
        return myioctl_major;
    }
    
    //read the counter value from file when started
    if (readCounterValueFromFile(&count) == 0) {
        pr_info("Previous counter value: %d\n", count);
    }
    
    pr_info("myioctl module loaded. Major number: %d\n", myioctl_major);
    return 0;
}

// module cleanup
static void __exit myioctl_exit(void) {
    // Save the counter value to the file at module exit
    if (saveCounterValueToFile(count) != 0) {
        pr_err("Error saving counter value to file\n");
    }
    
    unregister_chrdev(myioctl_major, "myioctl");
    pr_info("myioctl module unloaded\n");
}

// open function
static int myioctl_open(struct inode *inode, struct file *filp) {
    pr_info("myioctl device opened\n");
    return 0;
}

// release function
static int myioctl_release(struct inode *inode, struct file *filp) {
    pr_info("myioctl device closed\n");
    return 0;
}

// IOCTL function
static long myioctl_ioctl(struct file *filp, unsigned int cmd, unsigned long arg) {
    int err = 0;
    int tmp;

    if (_IOC_TYPE(cmd) != MYIOCTL_MAGIC) {
        pr_err("Invalid magic number\n");
        return -ENOTTY;
    }

    // main IOCTL switch case
    switch (cmd) {
        case MYIOCTL_RESET:
            pr_info("IOCTL: Resetting counter\n");
            count = 0;
            break;
        
        case MYIOCTL_GET_COUNT:
            pr_info("IOCTL: Getting counter value\n");
            err = copy_to_user((int *)arg, &count, sizeof(int));
            break;

        case MYIOCTL_INCREMENT:
            pr_info("IOCTL: Incrementing counter\n");
            err = copy_from_user(&tmp, (int *)arg, sizeof(int));
            if (err == 0) {
                count += tmp;
            }
            break;

        default:
            pr_err("Unknown IOCTL command\n");
            return -ENOTTY;
    }

    // main IOCTL switch case error handling
    return err;
}

// main module operation
module_init(myioctl_init);
module_exit(myioctl_exit);
