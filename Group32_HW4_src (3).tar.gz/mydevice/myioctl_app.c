// Include necessary headers
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

// Define the marco and fill the module information
#define MYIOCTL_MAGIC 'k'
#define MYIOCTL_RESET _IO(MYIOCTL_MAGIC, 0)
#define MYIOCTL_GET_COUNT _IOR(MYIOCTL_MAGIC, 1, int)
#define MYIOCTL_INCREMENT _IOW(MYIOCTL_MAGIC, 2, int)

#define COUNTER_FILE_PATH "myioctl_persistent_counter"

//save counter value to the the counter_file_path
int saveCounterValueToFile(int counter_value) {
    FILE *file = fopen(COUNTER_FILE_PATH, "w");
    if (file != NULL) {
        fprintf(file, "%d", counter_value);
        fclose(file);
        return 0;  // Success
    }
    return -1;  // Error
}

//read previous counter value to the counter_file_path
int readCounterValueFromFile(int *counter_value) {
    FILE *file = fopen(COUNTER_FILE_PATH, "r");
    if (file != NULL) {
        fscanf(file, "%d", counter_value);
        fclose(file);
        return 0;  // Success
    }
    return -1;  // Error
}

int main() {
    // Open the device for I/O control
    int fd = open("/dev/myioctl", O_RDWR);

    if (fd == -1) {
        perror("Error opening myioctl devide");
        return -1;
    }

    //read counter value
    int counter_value;
    if (readCounterValueFromFile(&counter_value) == 0) {
        printf("Previous counter value: %d\n", counter_value);
    }
    
    // example: get the current counter value
    ioctl(fd, MYIOCTL_GET_COUNT, &counter_value);
    printf("Current counter value: %d\n", counter_value);

    // example: increment the counter by user input
    int increment_value;
    printf("Enter the value to increment the counter: ");
    if(scanf("%d", &increment_value) != 1) {
        perror("Error reading input");
        close(fd);
        return -1;
    }

    ioctl(fd, MYIOCTL_INCREMENT, &increment_value);

    // example: get the updated counter
    ioctl(fd, MYIOCTL_GET_COUNT, &counter_value);
    printf("Updated counter value: %d\n", counter_value);
    
    //save counter value after incremental value
    if (saveCounterValueToFile(counter_value) != 0) {
        perror("Error saving counter value to file");
    }
    
    close(fd);

    return 0;
}
